<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Prisijungimo vertimai
    |--------------------------------------------------------------------------
    |
    | Šios eilutės naudojamos vertimams, kurie
    | rodomi atliekant prisijungimo veiksmą.
    |
    */

    'failed'   => 'Prisijungimo duomenys neatitinka.',
    'throttle' => 'Per daug bandymų prisijungti. Bandykite po :seconds sec.',
];
