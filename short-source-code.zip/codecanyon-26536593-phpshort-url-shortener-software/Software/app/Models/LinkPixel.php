<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LinkPixel extends Model
{
    //

    protected $table = 'link_pixel';
}
