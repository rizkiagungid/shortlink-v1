<?php

return [
    'iOS',
    'Android',
    'Windows',
    'OS X',
    'Linux',
    'Ubuntu',
    'Chrome OS'
];