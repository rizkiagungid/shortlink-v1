<?php

return [
    'types' => [
        'browser', 'cities', 'clicks', 'clicks_hours', 'country', 'device', 'language', 'platform', 'referrer'
    ]
];