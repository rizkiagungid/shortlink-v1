Update documentation is available at:
https://lunatio.com/phpshort/documentation#update